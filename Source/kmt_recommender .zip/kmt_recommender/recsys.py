import pandas as pd
import argparse
import json
from collections import defaultdict
from surprise import Reader, Dataset, evaluate
from surprise import KNNBasic, NMF, SVD


# Get Script Arguments
def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--n_recs', help='Specify # recommendations/user (Default: 20)', default=20, action='store')
    parser.add_argument('--all_users', help='Dump JSON for all users top-N recommendations', action='store_true')
    parser.add_argument('--user_id', help='Dump JSON for specified user top-N recommendations', type=int, action='store')
    args = parser.parse_args()
    return args


def get_new_top_n(predictions, n=10):
    '''Return the top-N recommendation for each user from a set of predictions.
    Args:
        predictions(list of Prediction objects): The list of predictions, as
            returned by the test method of an algorithm.
        n(int): The number of recommendation to output for each user. Default
            is 10.
    Returns:
    A dict where keys are user (raw) ids and values are lists of tuples:
        [(raw item id, rating estimation), ...] of size n.
    '''

    # First map the predictions to each user.
    top_n = defaultdict(list)
    for uid, iid, true_r, est, _ in predictions:
        top_n[uid].append((iid, est))

    # Then sort the predictions for each user and retrieve the k highest ones.
    for uid, user_ratings in top_n.items():
        user_ratings.sort(key=lambda x: x[1], reverse=True)
        top_n[uid] = user_ratings[:n]

    return top_n


def trim_data(df, max_users=10, max_items=10):
    new_df = df[(df['user_id'] <= max_users) & (df['item_id'] <= max_items)]
    return new_df


def load_data(infile, max_users=100, max_items=200):

    header = ['user_id', 'item_id', 'rating']
    df = pd.read_csv(infile, sep='\t', names=header)

    print df.head(10)
    print df.shape

    n_users = df.user_id.unique().shape[0]
    n_items = df.item_id.unique().shape[0]
    # print 'Number of users = ' + str(n_users) + ' | Number of articles = ' + str(n_items)

    if max_users or max_items:
        df = trim_data(df, max_users, max_items)
        n_users = df.user_id.unique().shape[0]
        n_items = df.item_id.unique().shape[0]
        print 'Number of users = ' + str(n_users) + ' | Number of articles = ' + str(n_items)

    df = map_uuids(df, debug=False)

    sparsity = round(1.0-len(df)/float(n_users*n_items), 3)
    print 'The sparsity level of data-set is ' + str(sparsity*100) + '%'

    # Define the format
    reader = Reader(line_format='user item rating timestamp', sep='\t')
    # Load the data from the file using the reader format
    data = Dataset.load_from_df(df[['user_id', 'item_id', 'rating']], reader=reader)

    return data


def map_uuids(df, debug=False):
    # Original User/Item IDs
    old_uid_l = sorted(df.user_id.unique())
    old_iid_l = sorted(df.item_id.unique())
    # print '[Original] Number of Users = ' + str(len(old_uid_l)) + ' | Number of Articles = ' + str(len(old_iid_l))
    # New User/Item IDs
    new_uid_l = pd.read_csv('user_article_log/user_uuids.csv')['user_id'].tolist()
    new_iid_l = pd.read_csv('user_article_log/article_uuids.csv')['article_id'].tolist()
    url_prefix = 'http://kmt.infiniticloud.com/infiniti/items/'
    url_postfix = '/0/'
    new_iid_l = [url_prefix + s + url_postfix for s in new_iid_l]
    # print '[New] Number of Users = ' + str(len(new_uid_l)) + ' | Number of Articles = ' + str(len(new_iid_l))
    # Create a Map between old & new User & Item IDs
    uid_map = dict(zip(old_uid_l, new_uid_l))
    if debug:
        with open('uid_map.json', 'w') as f:
            json.dump(uid_map, f, sort_keys=True, indent=4, separators=(',', ': '))
    iid_map = dict(zip(old_iid_l, new_iid_l))
    if debug:
        with open('iid_map.json', 'w') as f:
            json.dump(iid_map, f, sort_keys=True, indent=4, separators=(',', ': '))
    # Convert df to new User/Item IDs
    df['user_id'] = df['user_id'].replace(uid_map)
    df['item_id'] = df['item_id'].replace(iid_map)
    return df


def main():

    # Get commandline arguments
    args = get_args()

    # Load data-set
    data = load_data('user_article_log/user_article_log.data', max_users=100, max_items=200)

    # Evaluating Singular Vector Decomposition
    # algo = SVD()
    # evaluate(algo, data, measures=['RMSE', 'MAE'])
    # # Evaluate Non-negative Matrix Factorization
    # algo = NMF()
    # evaluate(algo, data, measures=['RMSE', 'MAE'])
    # # Evaluate K-Nearest Neighbors Algorithm
    # algo = KNNBasic()
    # evaluate(algo, data, measures=['RMSE', 'MAE'])

    trainset = data.build_full_trainset()
    algo = KNNBasic()
    algo.train(trainset)

    # Than predict ratings for all pairs (u, i) that are NOT in the training set.
    testset = trainset.build_anti_testset()
    predictions = algo.test(testset)

    top_n = get_new_top_n(predictions, n=args.n_recs)

    rec_d = dict()
    for uid, user_ratings in top_n.items():
        rec_d[uid] = [iid for (iid, _) in user_ratings]
        # print(uid, [iid for (iid, _) in user_ratings])

    if args.all_users:
        print 'Generating recommendation for all users....'
        with open('output/all_user_recs.json', 'w') as f:
            json.dump(rec_d, f, sort_keys=True, indent=4, separators=(',', ': '))

    if args.user_id:
        print 'Generating recommendation for user {}....'.format(args.user_id)
        with open('output/' + str(args.user_id) + '_recs.json', 'w') as f:
            json.dump(rec_d[args.user_id], f, sort_keys=True, indent=4, separators=(',', ': '))


if __name__ == "__main__":
    main()
